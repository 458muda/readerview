var express = require('express');
var router = express.Router();
var read = require('node-readability');
var needle = require('needle');
var extractor = require('unfluff');

router.get('/' , function(req, res) {

//var url = "http://www.apherald.com/Politics/ViewArticle/155675/tamilanadu-news-tamilanadu-cm-jayalalitha-sufferin/";
needle.get(req.query.url, function(error, response) {
  if (!error && response.statusCode == 200){
  		// data = extractor.lazy(response.body, '');
  		 
        read(response.body, function(err, article, meta) {

         var dom = article.document;
         var data = extractor.lazy(article.html, '');
         var img = data.image();
           if(img == null){
           	var content = '<html><head><meta charset="utf-8"><title>'+dom.title+'</title></head><body>' +article.content+'</body></html>';
          		} else {
          	//console.log(url.parse(req.url).pathname);
          	var content = '<html><head><meta charset="utf-8"><title>'+dom.title+'</title></head><body><div><img src = ' + img + '> </div>' +article.content+'</body></html>';
          		 }
        	 res.write(content);
         // Close article to clean up jsdom and prevent leaks
 		 article.close();
        });
  }
});



});

module.exports = router;

